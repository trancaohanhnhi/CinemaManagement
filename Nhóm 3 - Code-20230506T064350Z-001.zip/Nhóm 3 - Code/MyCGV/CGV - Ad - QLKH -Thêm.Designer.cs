﻿namespace MyCGV
{
    partial class FormThemQLKH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormThemQLKH));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lbghichu = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dtthemngaykt = new System.Windows.Forms.DateTimePicker();
            this.lbngayketthuc = new System.Windows.Forms.Label();
            this.btxnthemqlkh = new System.Windows.Forms.Button();
            this.bthuyqlkh = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dtthemngaykc = new System.Windows.Forms.DateTimePicker();
            this.lbngaykhoichieu = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tbthemmpkh = new System.Windows.Forms.TextBox();
            this.lbmaphim = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cbthemmckh = new System.Windows.Forms.ComboBox();
            this.lbmacum = new System.Windows.Forms.Label();
            this.tbghichu = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.btxnthemqlkh);
            this.panel1.Controls.Add(this.bthuyqlkh);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(551, 574);
            this.panel1.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.tbghichu);
            this.panel6.Controls.Add(this.lbghichu);
            this.panel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel6.Location = new System.Drawing.Point(26, 300);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(496, 138);
            this.panel6.TabIndex = 4;
            // 
            // lbghichu
            // 
            this.lbghichu.AutoSize = true;
            this.lbghichu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbghichu.Location = new System.Drawing.Point(3, 22);
            this.lbghichu.Name = "lbghichu";
            this.lbghichu.Size = new System.Drawing.Size(94, 29);
            this.lbghichu.TabIndex = 0;
            this.lbghichu.Text = "Ghi chú";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dtthemngaykt);
            this.panel4.Controls.Add(this.lbngayketthuc);
            this.panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(26, 231);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(496, 65);
            this.panel4.TabIndex = 3;
            // 
            // dtthemngaykt
            // 
            this.dtthemngaykt.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtthemngaykt.Location = new System.Drawing.Point(213, 18);
            this.dtthemngaykt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtthemngaykt.Name = "dtthemngaykt";
            this.dtthemngaykt.Size = new System.Drawing.Size(180, 35);
            this.dtthemngaykt.TabIndex = 0;
            this.dtthemngaykt.Value = new System.DateTime(2023, 3, 25, 0, 0, 0, 0);
            // 
            // lbngayketthuc
            // 
            this.lbngayketthuc.AutoSize = true;
            this.lbngayketthuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbngayketthuc.Location = new System.Drawing.Point(3, 22);
            this.lbngayketthuc.Name = "lbngayketthuc";
            this.lbngayketthuc.Size = new System.Drawing.Size(157, 29);
            this.lbngayketthuc.TabIndex = 0;
            this.lbngayketthuc.Text = "Ngày kết thúc";
            // 
            // btxnthemqlkh
            // 
            this.btxnthemqlkh.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btxnthemqlkh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btxnthemqlkh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btxnthemqlkh.Location = new System.Drawing.Point(360, 481);
            this.btxnthemqlkh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btxnthemqlkh.Name = "btxnthemqlkh";
            this.btxnthemqlkh.Size = new System.Drawing.Size(137, 40);
            this.btxnthemqlkh.TabIndex = 5;
            this.btxnthemqlkh.Text = "Xác nhận";
            this.btxnthemqlkh.UseVisualStyleBackColor = false;
            this.btxnthemqlkh.Click += new System.EventHandler(this.btxnthemqlkh_Click);
            // 
            // bthuyqlkh
            // 
            this.bthuyqlkh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bthuyqlkh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bthuyqlkh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bthuyqlkh.Location = new System.Drawing.Point(237, 481);
            this.bthuyqlkh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bthuyqlkh.Name = "bthuyqlkh";
            this.bthuyqlkh.Size = new System.Drawing.Size(81, 41);
            this.bthuyqlkh.TabIndex = 6;
            this.bthuyqlkh.Text = "Hủy";
            this.bthuyqlkh.UseVisualStyleBackColor = false;
            this.bthuyqlkh.Click += new System.EventHandler(this.bthuyqlkh_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dtthemngaykc);
            this.panel5.Controls.Add(this.lbngaykhoichieu);
            this.panel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel5.Location = new System.Drawing.Point(26, 165);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(496, 60);
            this.panel5.TabIndex = 2;
            // 
            // dtthemngaykc
            // 
            this.dtthemngaykc.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtthemngaykc.Location = new System.Drawing.Point(210, 16);
            this.dtthemngaykc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtthemngaykc.Name = "dtthemngaykc";
            this.dtthemngaykc.Size = new System.Drawing.Size(182, 35);
            this.dtthemngaykc.TabIndex = 0;
            this.dtthemngaykc.Value = new System.DateTime(2023, 3, 26, 0, 0, 0, 0);
            // 
            // lbngaykhoichieu
            // 
            this.lbngaykhoichieu.AutoSize = true;
            this.lbngaykhoichieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbngaykhoichieu.Location = new System.Drawing.Point(3, 22);
            this.lbngaykhoichieu.Name = "lbngaykhoichieu";
            this.lbngaykhoichieu.Size = new System.Drawing.Size(184, 29);
            this.lbngaykhoichieu.TabIndex = 0;
            this.lbngaykhoichieu.Text = "Ngày khởi chiếu";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tbthemmpkh);
            this.panel3.Controls.Add(this.lbmaphim);
            this.panel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(26, 99);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(496, 60);
            this.panel3.TabIndex = 1;
            // 
            // tbthemmpkh
            // 
            this.tbthemmpkh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbthemmpkh.Location = new System.Drawing.Point(210, 16);
            this.tbthemmpkh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbthemmpkh.Name = "tbthemmpkh";
            this.tbthemmpkh.Size = new System.Drawing.Size(277, 35);
            this.tbthemmpkh.TabIndex = 0;
            // 
            // lbmaphim
            // 
            this.lbmaphim.AutoSize = true;
            this.lbmaphim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmaphim.Location = new System.Drawing.Point(3, 19);
            this.lbmaphim.Name = "lbmaphim";
            this.lbmaphim.Size = new System.Drawing.Size(105, 29);
            this.lbmaphim.TabIndex = 0;
            this.lbmaphim.Text = "Mã phim";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cbthemmckh);
            this.panel2.Controls.Add(this.lbmacum);
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(26, 32);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(496, 60);
            this.panel2.TabIndex = 0;
            // 
            // cbthemmckh
            // 
            this.cbthemmckh.FormattingEnabled = true;
            this.cbthemmckh.Location = new System.Drawing.Point(210, 11);
            this.cbthemmckh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbthemmckh.Name = "cbthemmckh";
            this.cbthemmckh.Size = new System.Drawing.Size(277, 37);
            this.cbthemmckh.TabIndex = 0;
            // 
            // lbmacum
            // 
            this.lbmacum.AutoSize = true;
            this.lbmacum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmacum.Location = new System.Drawing.Point(3, 19);
            this.lbmacum.Name = "lbmacum";
            this.lbmacum.Size = new System.Drawing.Size(97, 29);
            this.lbmacum.TabIndex = 0;
            this.lbmacum.Text = "Mã cụm";
            // 
            // tbghichu
            // 
            this.tbghichu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbghichu.Location = new System.Drawing.Point(194, 22);
            this.tbghichu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbghichu.Multiline = true;
            this.tbghichu.Name = "tbghichu";
            this.tbghichu.Size = new System.Drawing.Size(277, 93);
            this.tbghichu.TabIndex = 1;
            // 
            // FormThemQLKH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(551, 574);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormThemQLKH";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CGV - Thêm Quản lý kế hoạch";
            this.Load += new System.EventHandler(this.FormThemQLKH_Load);
            this.panel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lbghichu;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DateTimePicker dtthemngaykt;
        private System.Windows.Forms.Label lbngayketthuc;
        private System.Windows.Forms.Button btxnthemqlkh;
        private System.Windows.Forms.Button bthuyqlkh;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DateTimePicker dtthemngaykc;
        private System.Windows.Forms.Label lbngaykhoichieu;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tbthemmpkh;
        private System.Windows.Forms.Label lbmaphim;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbmacum;
        private System.Windows.Forms.ComboBox cbthemmckh;
        private System.Windows.Forms.TextBox tbghichu;
    }
}