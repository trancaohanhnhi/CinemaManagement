﻿namespace MyCGV
{
    partial class FormSửa_rạp_quận_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSửa_rạp_quận_1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.tbsuamcq1 = new System.Windows.Forms.TextBox();
            this.btxacnhansrq1 = new System.Windows.Forms.Button();
            this.bthuysrq1 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.nudsogheq1 = new System.Windows.Forms.NumericUpDown();
            this.lbsogheq1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbmarapq1 = new System.Windows.Forms.Label();
            this.tbmarapq1 = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudsogheq1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.btxacnhansrq1);
            this.panel1.Controls.Add(this.bthuysrq1);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(513, 338);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.tbsuamcq1);
            this.panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(12, 164);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(488, 64);
            this.panel4.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã cụm";
            // 
            // tbsuamcq1
            // 
            this.tbsuamcq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbsuamcq1.Location = new System.Drawing.Point(153, 18);
            this.tbsuamcq1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbsuamcq1.Name = "tbsuamcq1";
            this.tbsuamcq1.ReadOnly = true;
            this.tbsuamcq1.Size = new System.Drawing.Size(304, 35);
            this.tbsuamcq1.TabIndex = 0;
            // 
            // btxacnhansrq1
            // 
            this.btxacnhansrq1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btxacnhansrq1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btxacnhansrq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btxacnhansrq1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btxacnhansrq1.Location = new System.Drawing.Point(302, 272);
            this.btxacnhansrq1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btxacnhansrq1.Name = "btxacnhansrq1";
            this.btxacnhansrq1.Size = new System.Drawing.Size(166, 40);
            this.btxacnhansrq1.TabIndex = 3;
            this.btxacnhansrq1.Text = "Xác nhận";
            this.btxacnhansrq1.UseVisualStyleBackColor = false;
            this.btxacnhansrq1.Click += new System.EventHandler(this.btxacnhansrq1_Click);
            // 
            // bthuysrq1
            // 
            this.bthuysrq1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bthuysrq1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bthuysrq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bthuysrq1.Location = new System.Drawing.Point(170, 272);
            this.bthuysrq1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bthuysrq1.Name = "bthuysrq1";
            this.bthuysrq1.Size = new System.Drawing.Size(100, 42);
            this.bthuysrq1.TabIndex = 4;
            this.bthuysrq1.Text = "Hủy";
            this.bthuysrq1.UseVisualStyleBackColor = false;
            this.bthuysrq1.Click += new System.EventHandler(this.bthuysrq1_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.nudsogheq1);
            this.panel3.Controls.Add(this.lbsogheq1);
            this.panel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(12, 94);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(488, 64);
            this.panel3.TabIndex = 1;
            // 
            // nudsogheq1
            // 
            this.nudsogheq1.Location = new System.Drawing.Point(153, 20);
            this.nudsogheq1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nudsogheq1.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nudsogheq1.Name = "nudsogheq1";
            this.nudsogheq1.Size = new System.Drawing.Size(108, 35);
            this.nudsogheq1.TabIndex = 0;
            // 
            // lbsogheq1
            // 
            this.lbsogheq1.AutoSize = true;
            this.lbsogheq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbsogheq1.Location = new System.Drawing.Point(22, 20);
            this.lbsogheq1.Name = "lbsogheq1";
            this.lbsogheq1.Size = new System.Drawing.Size(90, 29);
            this.lbsogheq1.TabIndex = 0;
            this.lbsogheq1.Text = "Số ghế";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbmarapq1);
            this.panel2.Controls.Add(this.tbmarapq1);
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(12, 24);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(488, 64);
            this.panel2.TabIndex = 0;
            // 
            // lbmarapq1
            // 
            this.lbmarapq1.AutoSize = true;
            this.lbmarapq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmarapq1.Location = new System.Drawing.Point(22, 20);
            this.lbmarapq1.Name = "lbmarapq1";
            this.lbmarapq1.Size = new System.Drawing.Size(87, 29);
            this.lbmarapq1.TabIndex = 0;
            this.lbmarapq1.Text = "Mã rạp";
            // 
            // tbmarapq1
            // 
            this.tbmarapq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbmarapq1.Location = new System.Drawing.Point(153, 18);
            this.tbmarapq1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbmarapq1.Name = "tbmarapq1";
            this.tbmarapq1.ReadOnly = true;
            this.tbmarapq1.Size = new System.Drawing.Size(304, 35);
            this.tbmarapq1.TabIndex = 0;
            // 
            // FormSửa_rạp_quận_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(513, 338);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormSửa_rạp_quận_1";
            this.Text = "CGV - Sửa rạp quận 1";
            this.Load += new System.EventHandler(this.FormSửa_rạp_quận_1_Load);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudsogheq1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tbmarapq1;
        private System.Windows.Forms.Label lbmarapq1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbsogheq1;
        private System.Windows.Forms.NumericUpDown nudsogheq1;
        private System.Windows.Forms.Button bthuysrq1;
        private System.Windows.Forms.Button btxacnhansrq1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbsuamcq1;
    }
}