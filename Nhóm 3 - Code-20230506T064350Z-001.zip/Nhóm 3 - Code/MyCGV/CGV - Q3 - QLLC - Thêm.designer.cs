﻿namespace Trang_chủ_của_NVQL
{
    partial class cgvquan3qllcthem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cgvquan3qllcthem));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.nxlct = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.cbraplct = new System.Windows.Forms.ComboBox();
            this.raplct = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.cbsuatchieulct = new System.Windows.Forms.ComboBox();
            this.suatchieulct = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpngaychieu = new System.Windows.Forms.DateTimePicker();
            this.ngaychieuclct = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.cbtenphimlct = new System.Windows.Forms.ComboBox();
            this.tenphimlct = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel9);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(862, 186);
            this.panel1.TabIndex = 0;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.nxlct);
            this.panel9.Location = new System.Drawing.Point(3, 127);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(855, 56);
            this.panel9.TabIndex = 6;
            // 
            // nxlct
            // 
            this.nxlct.BackColor = System.Drawing.Color.PaleTurquoise;
            this.nxlct.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.nxlct.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nxlct.Location = new System.Drawing.Point(723, 10);
            this.nxlct.Name = "nxlct";
            this.nxlct.Size = new System.Drawing.Size(117, 34);
            this.nxlct.TabIndex = 4;
            this.nxlct.Text = "Xác nhận";
            this.nxlct.UseVisualStyleBackColor = false;
            this.nxlct.Click += new System.EventHandler(this.nxlct_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label3);
            this.panel8.Controls.Add(this.cbraplct);
            this.panel8.Controls.Add(this.raplct);
            this.panel8.Location = new System.Drawing.Point(470, 65);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(388, 60);
            this.panel8.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(134, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "(3)";
            // 
            // cbraplct
            // 
            this.cbraplct.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbraplct.FormattingEnabled = true;
            this.cbraplct.Location = new System.Drawing.Point(173, 14);
            this.cbraplct.Name = "cbraplct";
            this.cbraplct.Size = new System.Drawing.Size(198, 33);
            this.cbraplct.TabIndex = 3;
            this.cbraplct.SelectedValueChanged += new System.EventHandler(this.cbraplct_SelectedValueChanged);
            // 
            // raplct
            // 
            this.raplct.AutoSize = true;
            this.raplct.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.raplct.Location = new System.Drawing.Point(18, 22);
            this.raplct.Name = "raplct";
            this.raplct.Size = new System.Drawing.Size(99, 25);
            this.raplct.TabIndex = 0;
            this.raplct.Text = "Rạp chiếu";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.cbsuatchieulct);
            this.panel6.Controls.Add(this.suatchieulct);
            this.panel6.Location = new System.Drawing.Point(470, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(388, 60);
            this.panel6.TabIndex = 4;
            // 
            // cbsuatchieulct
            // 
            this.cbsuatchieulct.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbsuatchieulct.FormattingEnabled = true;
            this.cbsuatchieulct.Location = new System.Drawing.Point(173, 8);
            this.cbsuatchieulct.Name = "cbsuatchieulct";
            this.cbsuatchieulct.Size = new System.Drawing.Size(200, 33);
            this.cbsuatchieulct.TabIndex = 2;
            // 
            // suatchieulct
            // 
            this.suatchieulct.AutoSize = true;
            this.suatchieulct.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.suatchieulct.Location = new System.Drawing.Point(18, 17);
            this.suatchieulct.Name = "suatchieulct";
            this.suatchieulct.Size = new System.Drawing.Size(105, 25);
            this.suatchieulct.TabIndex = 0;
            this.suatchieulct.Text = "Suất chiếu";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.dtpngaychieu);
            this.panel3.Controls.Add(this.ngaychieuclct);
            this.panel3.Location = new System.Drawing.Point(3, 65);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(465, 60);
            this.panel3.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(160, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "(2)";
            // 
            // dtpngaychieu
            // 
            this.dtpngaychieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.dtpngaychieu.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpngaychieu.Location = new System.Drawing.Point(205, 12);
            this.dtpngaychieu.Name = "dtpngaychieu";
            this.dtpngaychieu.Size = new System.Drawing.Size(209, 30);
            this.dtpngaychieu.TabIndex = 3;
            this.dtpngaychieu.ValueChanged += new System.EventHandler(this.dtpngaychieu_ValueChanged);
            // 
            // ngaychieuclct
            // 
            this.ngaychieuclct.AutoSize = true;
            this.ngaychieuclct.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ngaychieuclct.Location = new System.Drawing.Point(32, 17);
            this.ngaychieuclct.Name = "ngaychieuclct";
            this.ngaychieuclct.Size = new System.Drawing.Size(110, 25);
            this.ngaychieuclct.TabIndex = 0;
            this.ngaychieuclct.Text = "Ngày chiếu";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.cbtenphimlct);
            this.panel2.Controls.Add(this.tenphimlct);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(465, 60);
            this.panel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(160, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "(1)";
            // 
            // cbtenphimlct
            // 
            this.cbtenphimlct.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbtenphimlct.FormattingEnabled = true;
            this.cbtenphimlct.Location = new System.Drawing.Point(205, 9);
            this.cbtenphimlct.Name = "cbtenphimlct";
            this.cbtenphimlct.Size = new System.Drawing.Size(209, 33);
            this.cbtenphimlct.TabIndex = 1;
            // 
            // tenphimlct
            // 
            this.tenphimlct.AutoSize = true;
            this.tenphimlct.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tenphimlct.Location = new System.Drawing.Point(32, 17);
            this.tenphimlct.Name = "tenphimlct";
            this.tenphimlct.Size = new System.Drawing.Size(94, 25);
            this.tenphimlct.TabIndex = 0;
            this.tenphimlct.Text = "Tên phim";
            // 
            // cgvquan3qllcthem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(862, 186);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "cgvquan3qllcthem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CGV Quận 3 - Quản lý lịch chiếu - Thêm lịch chiếu";
            this.Load += new System.EventHandler(this.cgvquan3qllcthem_Load);
            this.panel1.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.ComboBox cbraplct;
        private System.Windows.Forms.Label raplct;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ComboBox cbsuatchieulct;
        private System.Windows.Forms.Label suatchieulct;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label ngaychieuclct;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox cbtenphimlct;
        private System.Windows.Forms.Label tenphimlct;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button nxlct;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpngaychieu;
    }
}