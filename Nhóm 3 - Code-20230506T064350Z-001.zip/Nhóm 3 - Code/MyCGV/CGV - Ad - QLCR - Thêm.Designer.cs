﻿namespace MyCGV
{
    partial class FormThêm_cụm_rạp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormThêm_cụm_rạp));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btxnthemcr = new System.Windows.Forms.Button();
            this.bthuythemcum = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tbthemdccum = new System.Windows.Forms.TextBox();
            this.lbdiachicum = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tbtencumthem = new System.Windows.Forms.TextBox();
            this.lbTencum = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbmacumthem = new System.Windows.Forms.TextBox();
            this.lbmacum = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btxnthemcr);
            this.panel1.Controls.Add(this.bthuythemcum);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(581, 441);
            this.panel1.TabIndex = 0;
            // 
            // btxnthemcr
            // 
            this.btxnthemcr.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btxnthemcr.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btxnthemcr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btxnthemcr.Location = new System.Drawing.Point(382, 356);
            this.btxnthemcr.Name = "btxnthemcr";
            this.btxnthemcr.Size = new System.Drawing.Size(137, 40);
            this.btxnthemcr.TabIndex = 3;
            this.btxnthemcr.Text = "Xác nhận";
            this.btxnthemcr.UseVisualStyleBackColor = false;
            this.btxnthemcr.Click += new System.EventHandler(this.btxnthemcr_Click);
            // 
            // bthuythemcum
            // 
            this.bthuythemcum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bthuythemcum.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bthuythemcum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bthuythemcum.Location = new System.Drawing.Point(259, 356);
            this.bthuythemcum.Name = "bthuythemcum";
            this.bthuythemcum.Size = new System.Drawing.Size(81, 41);
            this.bthuythemcum.TabIndex = 4;
            this.bthuythemcum.Text = "Hủy";
            this.bthuythemcum.UseVisualStyleBackColor = false;
            this.bthuythemcum.Click += new System.EventHandler(this.bthuythemcum_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.tbthemdccum);
            this.panel4.Controls.Add(this.lbdiachicum);
            this.panel4.Location = new System.Drawing.Point(37, 176);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(510, 120);
            this.panel4.TabIndex = 2;
            // 
            // tbthemdccum
            // 
            this.tbthemdccum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbthemdccum.Location = new System.Drawing.Point(190, 22);
            this.tbthemdccum.Multiline = true;
            this.tbthemdccum.Name = "tbthemdccum";
            this.tbthemdccum.Size = new System.Drawing.Size(277, 75);
            this.tbthemdccum.TabIndex = 0;
            // 
            // lbdiachicum
            // 
            this.lbdiachicum.AutoSize = true;
            this.lbdiachicum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbdiachicum.Location = new System.Drawing.Point(3, 22);
            this.lbdiachicum.Name = "lbdiachicum";
            this.lbdiachicum.Size = new System.Drawing.Size(86, 29);
            this.lbdiachicum.TabIndex = 0;
            this.lbdiachicum.Text = "Địa chỉ";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tbtencumthem);
            this.panel3.Controls.Add(this.lbTencum);
            this.panel3.Location = new System.Drawing.Point(37, 110);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(510, 60);
            this.panel3.TabIndex = 1;
            // 
            // tbtencumthem
            // 
            this.tbtencumthem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbtencumthem.Location = new System.Drawing.Point(190, 16);
            this.tbtencumthem.Name = "tbtencumthem";
            this.tbtencumthem.Size = new System.Drawing.Size(277, 35);
            this.tbtencumthem.TabIndex = 0;
            // 
            // lbTencum
            // 
            this.lbTencum.AutoSize = true;
            this.lbTencum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTencum.Location = new System.Drawing.Point(3, 19);
            this.lbTencum.Name = "lbTencum";
            this.lbTencum.Size = new System.Drawing.Size(148, 29);
            this.lbTencum.TabIndex = 0;
            this.lbTencum.Text = "Tên cụm rạp";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tbmacumthem);
            this.panel2.Controls.Add(this.lbmacum);
            this.panel2.Location = new System.Drawing.Point(37, 44);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(510, 60);
            this.panel2.TabIndex = 0;
            // 
            // tbmacumthem
            // 
            this.tbmacumthem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbmacumthem.Location = new System.Drawing.Point(190, 16);
            this.tbmacumthem.Name = "tbmacumthem";
            this.tbmacumthem.Size = new System.Drawing.Size(277, 35);
            this.tbmacumthem.TabIndex = 0;
            // 
            // lbmacum
            // 
            this.lbmacum.AutoSize = true;
            this.lbmacum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmacum.Location = new System.Drawing.Point(3, 19);
            this.lbmacum.Name = "lbmacum";
            this.lbmacum.Size = new System.Drawing.Size(97, 29);
            this.lbmacum.TabIndex = 0;
            this.lbmacum.Text = "Mã cụm";
            // 
            // FormThêm_cụm_rạp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(581, 441);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormThêm_cụm_rạp";
            this.Text = "CGV - Thêm cụm rạp";
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tbmacumthem;
        private System.Windows.Forms.Label lbmacum;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tbtencumthem;
        private System.Windows.Forms.Label lbTencum;
        private System.Windows.Forms.Button bthuythemcum;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbdiachicum;
        private System.Windows.Forms.Button btxnthemcr;
        private System.Windows.Forms.TextBox tbthemdccum;
    }
}