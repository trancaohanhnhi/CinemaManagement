﻿namespace MyCGV
{
    partial class FormSửa_phim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSửa_phim));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cbsuatlp = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbsuaphimlongtieng = new System.Windows.Forms.CheckBox();
            this.cbsuaphim3d = new System.Windows.Forms.CheckBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.nudthoiluongsua = new System.Windows.Forms.NumericUpDown();
            this.lbthoiluong = new System.Windows.Forms.Label();
            this.btxnsuaphim = new System.Windows.Forms.Button();
            this.bthuysuaphim = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.cbsuatlc = new System.Windows.Forms.ComboBox();
            this.lbtlchinh = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tbtenphimsua = new System.Windows.Forms.TextBox();
            this.lbTenphim = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbmaphimsua = new System.Windows.Forms.TextBox();
            this.lbmaphim = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudthoiluongsua)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.cbsuaphimlongtieng);
            this.panel1.Controls.Add(this.cbsuaphim3d);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.btxnsuaphim);
            this.panel1.Controls.Add(this.bthuysuaphim);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(464, 475);
            this.panel1.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.cbsuatlp);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(23, 185);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(420, 48);
            this.panel4.TabIndex = 4;
            // 
            // cbsuatlp
            // 
            this.cbsuatlp.FormattingEnabled = true;
            this.cbsuatlp.Location = new System.Drawing.Point(169, 11);
            this.cbsuatlp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbsuatlp.Name = "cbsuatlp";
            this.cbsuatlp.Size = new System.Drawing.Size(247, 33);
            this.cbsuatlp.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Thể loại phụ";
            // 
            // cbsuaphimlongtieng
            // 
            this.cbsuaphimlongtieng.AutoSize = true;
            this.cbsuaphimlongtieng.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbsuaphimlongtieng.Location = new System.Drawing.Point(260, 365);
            this.cbsuaphimlongtieng.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbsuaphimlongtieng.Name = "cbsuaphimlongtieng";
            this.cbsuaphimlongtieng.Size = new System.Drawing.Size(125, 29);
            this.cbsuaphimlongtieng.TabIndex = 7;
            this.cbsuaphimlongtieng.Text = "Lồng tiếng";
            this.cbsuaphimlongtieng.UseVisualStyleBackColor = true;
            // 
            // cbsuaphim3d
            // 
            this.cbsuaphim3d.AutoSize = true;
            this.cbsuaphim3d.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbsuaphim3d.Location = new System.Drawing.Point(100, 365);
            this.cbsuaphim3d.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbsuaphim3d.Name = "cbsuaphim3d";
            this.cbsuaphim3d.Size = new System.Drawing.Size(59, 29);
            this.cbsuaphim3d.TabIndex = 6;
            this.cbsuaphim3d.Text = "3D";
            this.cbsuaphim3d.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.nudthoiluongsua);
            this.panel6.Controls.Add(this.lbthoiluong);
            this.panel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel6.Location = new System.Drawing.Point(23, 247);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(420, 58);
            this.panel6.TabIndex = 4;
            // 
            // nudthoiluongsua
            // 
            this.nudthoiluongsua.Location = new System.Drawing.Point(206, 13);
            this.nudthoiluongsua.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nudthoiluongsua.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nudthoiluongsua.Name = "nudthoiluongsua";
            this.nudthoiluongsua.Size = new System.Drawing.Size(107, 30);
            this.nudthoiluongsua.TabIndex = 1;
            // 
            // lbthoiluong
            // 
            this.lbthoiluong.AutoSize = true;
            this.lbthoiluong.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbthoiluong.Location = new System.Drawing.Point(3, 18);
            this.lbthoiluong.Name = "lbthoiluong";
            this.lbthoiluong.Size = new System.Drawing.Size(161, 25);
            this.lbthoiluong.TabIndex = 0;
            this.lbthoiluong.Text = "Thời lượng (phút)";
            // 
            // btxnsuaphim
            // 
            this.btxnsuaphim.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btxnsuaphim.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btxnsuaphim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btxnsuaphim.Location = new System.Drawing.Point(316, 421);
            this.btxnsuaphim.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btxnsuaphim.Name = "btxnsuaphim";
            this.btxnsuaphim.Size = new System.Drawing.Size(122, 32);
            this.btxnsuaphim.TabIndex = 5;
            this.btxnsuaphim.Text = "Xác nhận";
            this.btxnsuaphim.UseVisualStyleBackColor = false;
            this.btxnsuaphim.Click += new System.EventHandler(this.btxnsuaphim_Click);
            // 
            // bthuysuaphim
            // 
            this.bthuysuaphim.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bthuysuaphim.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bthuysuaphim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bthuysuaphim.Location = new System.Drawing.Point(207, 421);
            this.bthuysuaphim.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bthuysuaphim.Name = "bthuysuaphim";
            this.bthuysuaphim.Size = new System.Drawing.Size(72, 33);
            this.bthuysuaphim.TabIndex = 4;
            this.bthuysuaphim.Text = "Hủy";
            this.bthuysuaphim.UseVisualStyleBackColor = false;
            this.bthuysuaphim.Click += new System.EventHandler(this.bthuysuaphim_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.cbsuatlc);
            this.panel5.Controls.Add(this.lbtlchinh);
            this.panel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel5.Location = new System.Drawing.Point(23, 132);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(420, 48);
            this.panel5.TabIndex = 3;
            // 
            // cbsuatlc
            // 
            this.cbsuatlc.FormattingEnabled = true;
            this.cbsuatlc.Location = new System.Drawing.Point(169, 11);
            this.cbsuatlc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbsuatlc.Name = "cbsuatlc";
            this.cbsuatlc.Size = new System.Drawing.Size(247, 33);
            this.cbsuatlc.TabIndex = 8;
            this.cbsuatlc.SelectedIndexChanged += new System.EventHandler(this.cbsuatlc_SelectedIndexChanged);
            // 
            // lbtlchinh
            // 
            this.lbtlchinh.AutoSize = true;
            this.lbtlchinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtlchinh.Location = new System.Drawing.Point(3, 18);
            this.lbtlchinh.Name = "lbtlchinh";
            this.lbtlchinh.Size = new System.Drawing.Size(134, 25);
            this.lbtlchinh.TabIndex = 0;
            this.lbtlchinh.Text = "Thể loại chính";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tbtenphimsua);
            this.panel3.Controls.Add(this.lbTenphim);
            this.panel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(23, 79);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(420, 48);
            this.panel3.TabIndex = 2;
            // 
            // tbtenphimsua
            // 
            this.tbtenphimsua.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbtenphimsua.Location = new System.Drawing.Point(169, 13);
            this.tbtenphimsua.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbtenphimsua.Name = "tbtenphimsua";
            this.tbtenphimsua.Size = new System.Drawing.Size(247, 30);
            this.tbtenphimsua.TabIndex = 1;
            // 
            // lbTenphim
            // 
            this.lbTenphim.AutoSize = true;
            this.lbTenphim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenphim.Location = new System.Drawing.Point(3, 15);
            this.lbTenphim.Name = "lbTenphim";
            this.lbTenphim.Size = new System.Drawing.Size(94, 25);
            this.lbTenphim.TabIndex = 0;
            this.lbTenphim.Text = "Tên phim";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tbmaphimsua);
            this.panel2.Controls.Add(this.lbmaphim);
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(23, 26);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(420, 48);
            this.panel2.TabIndex = 1;
            // 
            // tbmaphimsua
            // 
            this.tbmaphimsua.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbmaphimsua.Location = new System.Drawing.Point(169, 13);
            this.tbmaphimsua.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbmaphimsua.Name = "tbmaphimsua";
            this.tbmaphimsua.ReadOnly = true;
            this.tbmaphimsua.Size = new System.Drawing.Size(247, 30);
            this.tbmaphimsua.TabIndex = 1;
            // 
            // lbmaphim
            // 
            this.lbmaphim.AutoSize = true;
            this.lbmaphim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmaphim.Location = new System.Drawing.Point(3, 15);
            this.lbmaphim.Name = "lbmaphim";
            this.lbmaphim.Size = new System.Drawing.Size(87, 25);
            this.lbmaphim.TabIndex = 0;
            this.lbmaphim.Text = "Mã phim";
            // 
            // FormSửa_phim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 475);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormSửa_phim";
            this.Text = "CGV - Sửa phim";
            this.Load += new System.EventHandler(this.FormSửa_phim_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudthoiluongsua)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox cbsuaphimlongtieng;
        private System.Windows.Forms.CheckBox cbsuaphim3d;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.NumericUpDown nudthoiluongsua;
        private System.Windows.Forms.Label lbthoiluong;
        private System.Windows.Forms.Button btxnsuaphim;
        private System.Windows.Forms.Button bthuysuaphim;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbtlchinh;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tbtenphimsua;
        private System.Windows.Forms.Label lbTenphim;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tbmaphimsua;
        private System.Windows.Forms.Label lbmaphim;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox cbsuatlp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbsuatlc;
    }
}