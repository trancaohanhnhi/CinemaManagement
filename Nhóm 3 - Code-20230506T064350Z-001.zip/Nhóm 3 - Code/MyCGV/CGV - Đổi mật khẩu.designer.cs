﻿namespace Trang_chủ_của_NVQL
{
    partial class cgvquan3doimk
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cgvquan3doimk));
            this.dmkmkht = new System.Windows.Forms.Label();
            this.dmkmkm = new System.Windows.Forms.Label();
            this.dmkxnmk = new System.Windows.Forms.Label();
            this.tbmkht = new System.Windows.Forms.TextBox();
            this.tbmkm = new System.Windows.Forms.TextBox();
            this.tbxnmk = new System.Windows.Forms.TextBox();
            this.btdmkxn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.tbtentk = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblthongbao = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btaxnmk = new System.Windows.Forms.PictureBox();
            this.bthxnmk = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btamkht = new System.Windows.Forms.PictureBox();
            this.bthmkht = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btamkm = new System.Windows.Forms.PictureBox();
            this.bthmkm = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btaxnmk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bthxnmk)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btamkht)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bthmkht)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btamkm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bthmkm)).BeginInit();
            this.SuspendLayout();
            // 
            // dmkmkht
            // 
            this.dmkmkht.AutoSize = true;
            this.dmkmkht.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.dmkmkht.Location = new System.Drawing.Point(25, 35);
            this.dmkmkht.Name = "dmkmkht";
            this.dmkmkht.Size = new System.Drawing.Size(198, 29);
            this.dmkmkht.TabIndex = 1;
            this.dmkmkht.Text = "Mật khẩu hiện tại:";
            // 
            // dmkmkm
            // 
            this.dmkmkm.AutoSize = true;
            this.dmkmkm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.dmkmkm.Location = new System.Drawing.Point(25, 28);
            this.dmkmkm.Name = "dmkmkm";
            this.dmkmkm.Size = new System.Drawing.Size(161, 29);
            this.dmkmkm.TabIndex = 2;
            this.dmkmkm.Text = "Mật khẩu mới:";
            // 
            // dmkxnmk
            // 
            this.dmkxnmk.AutoSize = true;
            this.dmkxnmk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.dmkxnmk.Location = new System.Drawing.Point(25, 29);
            this.dmkxnmk.Name = "dmkxnmk";
            this.dmkxnmk.Size = new System.Drawing.Size(221, 29);
            this.dmkxnmk.TabIndex = 3;
            this.dmkxnmk.Text = "Xác nhận mật khẩu:";
            // 
            // tbmkht
            // 
            this.tbmkht.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbmkht.Location = new System.Drawing.Point(255, 29);
            this.tbmkht.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbmkht.Name = "tbmkht";
            this.tbmkht.PasswordChar = '*';
            this.tbmkht.Size = new System.Drawing.Size(367, 35);
            this.tbmkht.TabIndex = 2;
            // 
            // tbmkm
            // 
            this.tbmkm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbmkm.Location = new System.Drawing.Point(255, 21);
            this.tbmkm.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbmkm.Name = "tbmkm";
            this.tbmkm.PasswordChar = '*';
            this.tbmkm.Size = new System.Drawing.Size(367, 35);
            this.tbmkm.TabIndex = 3;
            this.tbmkm.Validated += new System.EventHandler(this.tbmkm_Validated);
            // 
            // tbxnmk
            // 
            this.tbxnmk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbxnmk.Location = new System.Drawing.Point(255, 22);
            this.tbxnmk.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbxnmk.Name = "tbxnmk";
            this.tbxnmk.PasswordChar = '*';
            this.tbxnmk.Size = new System.Drawing.Size(367, 35);
            this.tbxnmk.TabIndex = 4;
            // 
            // btdmkxn
            // 
            this.btdmkxn.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btdmkxn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btdmkxn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btdmkxn.Location = new System.Drawing.Point(544, 19);
            this.btdmkxn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btdmkxn.Name = "btdmkxn";
            this.btdmkxn.Size = new System.Drawing.Size(129, 49);
            this.btdmkxn.TabIndex = 5;
            this.btdmkxn.Text = "Xác nhận";
            this.btdmkxn.UseVisualStyleBackColor = false;
            this.btdmkxn.Click += new System.EventHandler(this.btdmkxn_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(700, 419);
            this.panel1.TabIndex = 9;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.tbtentk);
            this.panel7.Controls.Add(this.label2);
            this.panel7.Location = new System.Drawing.Point(3, 4);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(691, 80);
            this.panel7.TabIndex = 0;
            // 
            // tbtentk
            // 
            this.tbtentk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbtentk.Location = new System.Drawing.Point(255, 29);
            this.tbtentk.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbtentk.Name = "tbtentk";
            this.tbtentk.Size = new System.Drawing.Size(367, 35);
            this.tbtentk.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(25, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên tài khoản:";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.lblthongbao);
            this.panel5.Controls.Add(this.btdmkxn);
            this.panel5.Location = new System.Drawing.Point(3, 334);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(691, 80);
            this.panel5.TabIndex = 12;
            // 
            // lblthongbao
            // 
            this.lblthongbao.AutoSize = true;
            this.lblthongbao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblthongbao.Location = new System.Drawing.Point(25, 19);
            this.lblthongbao.MinimumSize = new System.Drawing.Size(338, 38);
            this.lblthongbao.Name = "lblthongbao";
            this.lblthongbao.Size = new System.Drawing.Size(338, 38);
            this.lblthongbao.TabIndex = 5;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btaxnmk);
            this.panel4.Controls.Add(this.bthxnmk);
            this.panel4.Controls.Add(this.tbxnmk);
            this.panel4.Controls.Add(this.dmkxnmk);
            this.panel4.Location = new System.Drawing.Point(3, 251);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(691, 80);
            this.panel4.TabIndex = 11;
            // 
            // btaxnmk
            // 
            this.btaxnmk.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btaxnmk.BackgroundImage")));
            this.btaxnmk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btaxnmk.Location = new System.Drawing.Point(640, 22);
            this.btaxnmk.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btaxnmk.Name = "btaxnmk";
            this.btaxnmk.Size = new System.Drawing.Size(34, 38);
            this.btaxnmk.TabIndex = 5;
            this.btaxnmk.TabStop = false;
            this.btaxnmk.Click += new System.EventHandler(this.btaxnmk_Click);
            // 
            // bthxnmk
            // 
            this.bthxnmk.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bthxnmk.BackgroundImage")));
            this.bthxnmk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bthxnmk.Location = new System.Drawing.Point(640, 22);
            this.bthxnmk.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bthxnmk.Name = "bthxnmk";
            this.bthxnmk.Size = new System.Drawing.Size(34, 38);
            this.bthxnmk.TabIndex = 4;
            this.bthxnmk.TabStop = false;
            this.bthxnmk.Click += new System.EventHandler(this.bthxnmk_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btamkht);
            this.panel2.Controls.Add(this.bthmkht);
            this.panel2.Controls.Add(this.tbmkht);
            this.panel2.Controls.Add(this.dmkmkht);
            this.panel2.Location = new System.Drawing.Point(3, 86);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(691, 80);
            this.panel2.TabIndex = 9;
            // 
            // btamkht
            // 
            this.btamkht.BackColor = System.Drawing.SystemColors.Control;
            this.btamkht.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btamkht.BackgroundImage")));
            this.btamkht.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btamkht.Location = new System.Drawing.Point(640, 29);
            this.btamkht.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btamkht.Name = "btamkht";
            this.btamkht.Size = new System.Drawing.Size(34, 38);
            this.btamkht.TabIndex = 3;
            this.btamkht.TabStop = false;
            this.btamkht.Click += new System.EventHandler(this.btamkht_Click);
            // 
            // bthmkht
            // 
            this.bthmkht.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bthmkht.BackgroundImage")));
            this.bthmkht.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bthmkht.Location = new System.Drawing.Point(640, 29);
            this.bthmkht.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bthmkht.Name = "bthmkht";
            this.bthmkht.Size = new System.Drawing.Size(34, 38);
            this.bthmkht.TabIndex = 2;
            this.bthmkht.TabStop = false;
            this.bthmkht.Click += new System.EventHandler(this.bthmkht_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btamkm);
            this.panel3.Controls.Add(this.bthmkm);
            this.panel3.Controls.Add(this.tbmkm);
            this.panel3.Controls.Add(this.dmkmkm);
            this.panel3.Location = new System.Drawing.Point(3, 169);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(691, 80);
            this.panel3.TabIndex = 10;
            // 
            // btamkm
            // 
            this.btamkm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btamkm.BackgroundImage")));
            this.btamkm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btamkm.Location = new System.Drawing.Point(640, 21);
            this.btamkm.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btamkm.Name = "btamkm";
            this.btamkm.Size = new System.Drawing.Size(34, 38);
            this.btamkm.TabIndex = 4;
            this.btamkm.TabStop = false;
            this.btamkm.Click += new System.EventHandler(this.btamkm_Click);
            // 
            // bthmkm
            // 
            this.bthmkm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bthmkm.BackgroundImage")));
            this.bthmkm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bthmkm.Location = new System.Drawing.Point(640, 21);
            this.bthmkm.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bthmkm.Name = "bthmkm";
            this.bthmkm.Size = new System.Drawing.Size(34, 38);
            this.bthmkm.TabIndex = 3;
            this.bthmkm.TabStop = false;
            this.bthmkm.Click += new System.EventHandler(this.bthmkm_Click);
            // 
            // cgvquan3doimk
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(700, 419);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "cgvquan3doimk";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CGV - Đổi mật khẩu";
            this.panel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btaxnmk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bthxnmk)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btamkht)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bthmkht)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btamkm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bthmkm)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label dmkmkht;
        private System.Windows.Forms.Label dmkmkm;
        private System.Windows.Forms.Label dmkxnmk;
        private System.Windows.Forms.TextBox tbmkht;
        private System.Windows.Forms.TextBox tbmkm;
        private System.Windows.Forms.TextBox tbxnmk;
        private System.Windows.Forms.Button btdmkxn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox bthxnmk;
        private System.Windows.Forms.PictureBox btamkht;
        private System.Windows.Forms.PictureBox bthmkht;
        private System.Windows.Forms.PictureBox bthmkm;
        private System.Windows.Forms.PictureBox btaxnmk;
        private System.Windows.Forms.PictureBox btamkm;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox tbtentk;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label lblthongbao;
    }
}