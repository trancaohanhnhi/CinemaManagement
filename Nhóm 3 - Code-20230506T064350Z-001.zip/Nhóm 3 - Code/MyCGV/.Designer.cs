﻿namespace MyCGV
{
    partial class FormThemTK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormThemTK));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.cbmc = new System.Windows.Forms.ComboBox();
            this.lbcumrap = new System.Windows.Forms.Label();
            this.btxnthemtk = new System.Windows.Forms.Button();
            this.bthuythemtk = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tbchutk = new System.Windows.Forms.TextBox();
            this.lbnv = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbthemmk = new System.Windows.Forms.TextBox();
            this.lbmktk = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tbthemtk = new System.Windows.Forms.TextBox();
            this.lbtentk = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.btxnthemtk);
            this.panel1.Controls.Add(this.bthuythemtk);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(516, 450);
            this.panel1.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.cbmc);
            this.panel5.Controls.Add(this.lbcumrap);
            this.panel5.Location = new System.Drawing.Point(12, 258);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(492, 60);
            this.panel5.TabIndex = 3;
            // 
            // cbmc
            // 
            this.cbmc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbmc.FormattingEnabled = true;
            this.cbmc.Location = new System.Drawing.Point(169, 11);
            this.cbmc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbmc.Name = "cbmc";
            this.cbmc.Size = new System.Drawing.Size(292, 37);
            this.cbmc.TabIndex = 0;
            // 
            // lbcumrap
            // 
            this.lbcumrap.AutoSize = true;
            this.lbcumrap.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbcumrap.Location = new System.Drawing.Point(3, 19);
            this.lbcumrap.Name = "lbcumrap";
            this.lbcumrap.Size = new System.Drawing.Size(97, 29);
            this.lbcumrap.TabIndex = 0;
            this.lbcumrap.Text = "Mã cụm";
            // 
            // btxnthemtk
            // 
            this.btxnthemtk.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btxnthemtk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btxnthemtk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btxnthemtk.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btxnthemtk.Location = new System.Drawing.Point(340, 358);
            this.btxnthemtk.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btxnthemtk.Name = "btxnthemtk";
            this.btxnthemtk.Size = new System.Drawing.Size(164, 40);
            this.btxnthemtk.TabIndex = 4;
            this.btxnthemtk.Text = "Xác nhận";
            this.btxnthemtk.UseVisualStyleBackColor = false;
            this.btxnthemtk.Click += new System.EventHandler(this.btxnthemtk_Click);
            // 
            // bthuythemtk
            // 
            this.bthuythemtk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bthuythemtk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bthuythemtk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bthuythemtk.Location = new System.Drawing.Point(181, 358);
            this.bthuythemtk.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bthuythemtk.Name = "bthuythemtk";
            this.bthuythemtk.Size = new System.Drawing.Size(118, 42);
            this.bthuythemtk.TabIndex = 5;
            this.bthuythemtk.Text = "Hủy";
            this.bthuythemtk.UseVisualStyleBackColor = false;
            this.bthuythemtk.Click += new System.EventHandler(this.bthuythemtk_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tbchutk);
            this.panel3.Controls.Add(this.lbnv);
            this.panel3.Location = new System.Drawing.Point(12, 191);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(492, 60);
            this.panel3.TabIndex = 2;
            // 
            // tbchutk
            // 
            this.tbchutk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbchutk.Location = new System.Drawing.Point(169, 12);
            this.tbchutk.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbchutk.Name = "tbchutk";
            this.tbchutk.Size = new System.Drawing.Size(292, 35);
            this.tbchutk.TabIndex = 0;
            // 
            // lbnv
            // 
            this.lbnv.AutoSize = true;
            this.lbnv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnv.Location = new System.Drawing.Point(3, 19);
            this.lbnv.Name = "lbnv";
            this.lbnv.Size = new System.Drawing.Size(158, 29);
            this.lbnv.TabIndex = 0;
            this.lbnv.Text = "Chủ tài khoản";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tbthemmk);
            this.panel2.Controls.Add(this.lbmktk);
            this.panel2.Location = new System.Drawing.Point(12, 125);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(492, 60);
            this.panel2.TabIndex = 1;
            // 
            // tbthemmk
            // 
            this.tbthemmk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbthemmk.Location = new System.Drawing.Point(169, 12);
            this.tbthemmk.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbthemmk.Name = "tbthemmk";
            this.tbthemmk.Size = new System.Drawing.Size(292, 35);
            this.tbthemmk.TabIndex = 0;
            // 
            // lbmktk
            // 
            this.lbmktk.AutoSize = true;
            this.lbmktk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmktk.Location = new System.Drawing.Point(3, 19);
            this.lbmktk.Name = "lbmktk";
            this.lbmktk.Size = new System.Drawing.Size(109, 29);
            this.lbmktk.TabIndex = 0;
            this.lbmktk.Text = "Mật khẩu";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.tbthemtk);
            this.panel4.Controls.Add(this.lbtentk);
            this.panel4.Location = new System.Drawing.Point(12, 59);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(492, 60);
            this.panel4.TabIndex = 0;
            // 
            // tbthemtk
            // 
            this.tbthemtk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbthemtk.Location = new System.Drawing.Point(169, 12);
            this.tbthemtk.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbthemtk.Name = "tbthemtk";
            this.tbthemtk.Size = new System.Drawing.Size(292, 35);
            this.tbthemtk.TabIndex = 0;
            // 
            // lbtentk
            // 
            this.lbtentk.AutoSize = true;
            this.lbtentk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtentk.Location = new System.Drawing.Point(3, 19);
            this.lbtentk.Name = "lbtentk";
            this.lbtentk.Size = new System.Drawing.Size(158, 29);
            this.lbtentk.TabIndex = 0;
            this.lbtentk.Text = "Tên tài khoản";
            // 
            // FormThemTK
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(516, 450);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormThemTK";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CGV - Thêm tài khoản";
            this.Load += new System.EventHandler(this.FormThemTK_Load);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbcumrap;
        private System.Windows.Forms.Button btxnthemtk;
        private System.Windows.Forms.Button bthuythemtk;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tbchutk;
        private System.Windows.Forms.Label lbnv;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tbthemmk;
        private System.Windows.Forms.Label lbmktk;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox tbthemtk;
        private System.Windows.Forms.Label lbtentk;
        private System.Windows.Forms.ComboBox cbmc;
    }
}