﻿namespace MyCGV
{
    partial class Thêm_suất_chiếu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Thêm_suất_chiếu));
            this.panel4 = new System.Windows.Forms.Panel();
            this.btxnthemxc = new System.Windows.Forms.Button();
            this.bthuythemsc = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.nudphutBD = new System.Windows.Forms.NumericUpDown();
            this.lbphutBD = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.nudgioBD = new System.Windows.Forms.NumericUpDown();
            this.lbgioBD = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbmasuat = new System.Windows.Forms.TextBox();
            this.lbmasuat = new System.Windows.Forms.Label();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudphutBD)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudgioBD)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btxnthemxc);
            this.panel4.Controls.Add(this.bthuythemsc);
            this.panel4.Controls.Add(this.panel3);
            this.panel4.Controls.Add(this.panel1);
            this.panel4.Controls.Add(this.panel2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(550, 372);
            this.panel4.TabIndex = 11;
            // 
            // btxnthemxc
            // 
            this.btxnthemxc.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btxnthemxc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btxnthemxc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btxnthemxc.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btxnthemxc.Location = new System.Drawing.Point(347, 271);
            this.btxnthemxc.Name = "btxnthemxc";
            this.btxnthemxc.Size = new System.Drawing.Size(163, 40);
            this.btxnthemxc.TabIndex = 4;
            this.btxnthemxc.Text = "Xác nhận";
            this.btxnthemxc.UseVisualStyleBackColor = false;
            this.btxnthemxc.Click += new System.EventHandler(this.btxnthemxc_Click);
            // 
            // bthuythemsc
            // 
            this.bthuythemsc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bthuythemsc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bthuythemsc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bthuythemsc.Location = new System.Drawing.Point(198, 271);
            this.bthuythemsc.Name = "bthuythemsc";
            this.bthuythemsc.Size = new System.Drawing.Size(97, 42);
            this.bthuythemsc.TabIndex = 0;
            this.bthuythemsc.Text = "Hủy";
            this.bthuythemsc.UseVisualStyleBackColor = false;
            this.bthuythemsc.Click += new System.EventHandler(this.bthuythemxc_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.nudphutBD);
            this.panel3.Controls.Add(this.lbphutBD);
            this.panel3.Location = new System.Drawing.Point(29, 179);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(497, 60);
            this.panel3.TabIndex = 3;
            // 
            // nudphutBD
            // 
            this.nudphutBD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.nudphutBD.Location = new System.Drawing.Point(169, 17);
            this.nudphutBD.Name = "nudphutBD";
            this.nudphutBD.Size = new System.Drawing.Size(82, 35);
            this.nudphutBD.TabIndex = 3;
            // 
            // lbphutBD
            // 
            this.lbphutBD.AutoSize = true;
            this.lbphutBD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbphutBD.Location = new System.Drawing.Point(3, 19);
            this.lbphutBD.Name = "lbphutBD";
            this.lbphutBD.Size = new System.Drawing.Size(146, 29);
            this.lbphutBD.TabIndex = 0;
            this.lbphutBD.Text = "Phút bắt đầu";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.nudgioBD);
            this.panel1.Controls.Add(this.lbgioBD);
            this.panel1.Location = new System.Drawing.Point(29, 113);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(497, 60);
            this.panel1.TabIndex = 2;
            // 
            // nudgioBD
            // 
            this.nudgioBD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.nudgioBD.Location = new System.Drawing.Point(169, 19);
            this.nudgioBD.Name = "nudgioBD";
            this.nudgioBD.Size = new System.Drawing.Size(82, 35);
            this.nudgioBD.TabIndex = 2;
            // 
            // lbgioBD
            // 
            this.lbgioBD.AutoSize = true;
            this.lbgioBD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbgioBD.Location = new System.Drawing.Point(3, 19);
            this.lbgioBD.Name = "lbgioBD";
            this.lbgioBD.Size = new System.Drawing.Size(136, 29);
            this.lbgioBD.TabIndex = 0;
            this.lbgioBD.Text = "Giờ bắt đầu";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tbmasuat);
            this.panel2.Controls.Add(this.lbmasuat);
            this.panel2.Location = new System.Drawing.Point(29, 47);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(497, 60);
            this.panel2.TabIndex = 1;
            // 
            // tbmasuat
            // 
            this.tbmasuat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbmasuat.Location = new System.Drawing.Point(169, 13);
            this.tbmasuat.Name = "tbmasuat";
            this.tbmasuat.Size = new System.Drawing.Size(312, 35);
            this.tbmasuat.TabIndex = 1;
            // 
            // lbmasuat
            // 
            this.lbmasuat.AutoSize = true;
            this.lbmasuat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmasuat.Location = new System.Drawing.Point(3, 19);
            this.lbmasuat.Name = "lbmasuat";
            this.lbmasuat.Size = new System.Drawing.Size(96, 29);
            this.lbmasuat.TabIndex = 0;
            this.lbmasuat.Text = "Mã suất";
            // 
            // Thêm_suất_chiếu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(550, 372);
            this.Controls.Add(this.panel4);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Thêm_suất_chiếu";
            this.Text = "CGV - Thêm suất chiếu";
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudphutBD)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudgioBD)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btxnthemxc;
        private System.Windows.Forms.Button bthuythemsc;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.NumericUpDown nudphutBD;
        private System.Windows.Forms.Label lbphutBD;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.NumericUpDown nudgioBD;
        private System.Windows.Forms.Label lbgioBD;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tbmasuat;
        private System.Windows.Forms.Label lbmasuat;
    }
}