﻿namespace Trang_chủ_của_NVQL
{
    partial class cgvquan3qlkhdkp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cgvquan3qlkhdkp));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.dgvdkp = new System.Windows.Forms.DataGridView();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btdk = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tbnkcdk = new System.Windows.Forms.TextBox();
            this.nkcdk = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tbnktdk = new System.Windows.Forms.TextBox();
            this.ntktdk = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tbghichudk = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbmaphimdk = new System.Windows.Forms.TextBox();
            this.maphimdk = new System.Windows.Forms.Label();
            this.MaPhim = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayKhoiChieu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayKetThuc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvdkp)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(919, 343);
            this.panel1.TabIndex = 1;
            // 
            // panel7
            // 
            this.panel7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel7.Controls.Add(this.dgvdkp);
            this.panel7.Location = new System.Drawing.Point(493, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(422, 334);
            this.panel7.TabIndex = 4;
            // 
            // dgvdkp
            // 
            this.dgvdkp.AllowUserToAddRows = false;
            this.dgvdkp.AllowUserToDeleteRows = false;
            this.dgvdkp.AllowUserToOrderColumns = true;
            this.dgvdkp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvdkp.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvdkp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvdkp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvdkp.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaPhim,
            this.NgayKhoiChieu,
            this.NgayKetThuc,
            this.GhiChu});
            this.dgvdkp.Location = new System.Drawing.Point(3, 3);
            this.dgvdkp.Name = "dgvdkp";
            this.dgvdkp.ReadOnly = true;
            this.dgvdkp.RowHeadersWidth = 51;
            this.dgvdkp.RowTemplate.Height = 24;
            this.dgvdkp.Size = new System.Drawing.Size(416, 328);
            this.dgvdkp.TabIndex = 0;
            this.dgvdkp.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvdkp_CellClick);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btdk);
            this.panel6.Location = new System.Drawing.Point(3, 267);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(488, 71);
            this.panel6.TabIndex = 3;
            // 
            // btdk
            // 
            this.btdk.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btdk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btdk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btdk.Location = new System.Drawing.Point(347, 19);
            this.btdk.Name = "btdk";
            this.btdk.Size = new System.Drawing.Size(115, 34);
            this.btdk.TabIndex = 0;
            this.btdk.Text = "Đăng ký";
            this.btdk.UseVisualStyleBackColor = false;
            this.btdk.Click += new System.EventHandler(this.btdk_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.tbnkcdk);
            this.panel4.Controls.Add(this.nkcdk);
            this.panel4.Location = new System.Drawing.Point(3, 69);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(488, 64);
            this.panel4.TabIndex = 2;
            // 
            // tbnkcdk
            // 
            this.tbnkcdk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbnkcdk.Location = new System.Drawing.Point(164, 17);
            this.tbnkcdk.Name = "tbnkcdk";
            this.tbnkcdk.ReadOnly = true;
            this.tbnkcdk.Size = new System.Drawing.Size(298, 30);
            this.tbnkcdk.TabIndex = 1;
            this.tbnkcdk.TabStop = false;
            // 
            // nkcdk
            // 
            this.nkcdk.AutoSize = true;
            this.nkcdk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.nkcdk.Location = new System.Drawing.Point(3, 22);
            this.nkcdk.Name = "nkcdk";
            this.nkcdk.Size = new System.Drawing.Size(151, 25);
            this.nkcdk.TabIndex = 0;
            this.nkcdk.Text = "Ngày khởi chiếu";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.tbnktdk);
            this.panel5.Controls.Add(this.ntktdk);
            this.panel5.Location = new System.Drawing.Point(3, 135);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(488, 64);
            this.panel5.TabIndex = 2;
            // 
            // tbnktdk
            // 
            this.tbnktdk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbnktdk.Location = new System.Drawing.Point(164, 17);
            this.tbnktdk.Name = "tbnktdk";
            this.tbnktdk.ReadOnly = true;
            this.tbnktdk.Size = new System.Drawing.Size(298, 30);
            this.tbnktdk.TabIndex = 2;
            this.tbnktdk.TabStop = false;
            // 
            // ntktdk
            // 
            this.ntktdk.AutoSize = true;
            this.ntktdk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ntktdk.Location = new System.Drawing.Point(3, 22);
            this.ntktdk.Name = "ntktdk";
            this.ntktdk.Size = new System.Drawing.Size(131, 25);
            this.ntktdk.TabIndex = 0;
            this.ntktdk.Text = "Ngày kết thúc";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tbghichudk);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(3, 201);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(488, 64);
            this.panel3.TabIndex = 2;
            // 
            // tbghichudk
            // 
            this.tbghichudk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbghichudk.Location = new System.Drawing.Point(164, 16);
            this.tbghichudk.Name = "tbghichudk";
            this.tbghichudk.ReadOnly = true;
            this.tbghichudk.Size = new System.Drawing.Size(298, 30);
            this.tbghichudk.TabIndex = 2;
            this.tbghichudk.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(3, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Ghi chú";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tbmaphimdk);
            this.panel2.Controls.Add(this.maphimdk);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(488, 64);
            this.panel2.TabIndex = 0;
            // 
            // tbmaphimdk
            // 
            this.tbmaphimdk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbmaphimdk.Location = new System.Drawing.Point(164, 17);
            this.tbmaphimdk.Name = "tbmaphimdk";
            this.tbmaphimdk.ReadOnly = true;
            this.tbmaphimdk.Size = new System.Drawing.Size(298, 30);
            this.tbmaphimdk.TabIndex = 1;
            this.tbmaphimdk.TabStop = false;
            // 
            // maphimdk
            // 
            this.maphimdk.AutoSize = true;
            this.maphimdk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.maphimdk.Location = new System.Drawing.Point(3, 22);
            this.maphimdk.Name = "maphimdk";
            this.maphimdk.Size = new System.Drawing.Size(87, 25);
            this.maphimdk.TabIndex = 0;
            this.maphimdk.Text = "Mã phim";
            // 
            // MaPhim
            // 
            this.MaPhim.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.MaPhim.DataPropertyName = "MaPhim";
            this.MaPhim.HeaderText = "Mã Phim";
            this.MaPhim.MinimumWidth = 6;
            this.MaPhim.Name = "MaPhim";
            this.MaPhim.ReadOnly = true;
            // 
            // NgayKhoiChieu
            // 
            this.NgayKhoiChieu.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NgayKhoiChieu.DataPropertyName = "NgayKhoiChieu";
            this.NgayKhoiChieu.HeaderText = "Ngày khởi chiếu";
            this.NgayKhoiChieu.MinimumWidth = 6;
            this.NgayKhoiChieu.Name = "NgayKhoiChieu";
            this.NgayKhoiChieu.ReadOnly = true;
            // 
            // NgayKetThuc
            // 
            this.NgayKetThuc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NgayKetThuc.DataPropertyName = "NgayKetThuc";
            this.NgayKetThuc.HeaderText = "Ngày kết thúc";
            this.NgayKetThuc.MinimumWidth = 6;
            this.NgayKetThuc.Name = "NgayKetThuc";
            this.NgayKetThuc.ReadOnly = true;
            // 
            // GhiChu
            // 
            this.GhiChu.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.GhiChu.DataPropertyName = "GhiChu";
            this.GhiChu.HeaderText = "Ghi chú";
            this.GhiChu.MinimumWidth = 6;
            this.GhiChu.Name = "GhiChu";
            this.GhiChu.ReadOnly = true;
            // 
            // cgvquan3qlkhdkp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(919, 343);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "cgvquan3qlkhdkp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CGV Quận 3 - Quản lý kế hoạch - Đăng ký phim";
            this.Load += new System.EventHandler(this.cgvquan3qlkhdkp_Load);
            this.panel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvdkp)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btdk;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox tbnktdk;
        private System.Windows.Forms.Label ntktdk;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox tbnkcdk;
        private System.Windows.Forms.Label nkcdk;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tbmaphimdk;
        private System.Windows.Forms.Label maphimdk;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.DataGridView dgvdkp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbghichudk;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaPhim;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayKhoiChieu;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayKetThuc;
        private System.Windows.Forms.DataGridViewTextBoxColumn GhiChu;
    }
}