﻿namespace MyCGV
{
    partial class Thêm_phim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cbthemtlp = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbthemphimlongtieng = new System.Windows.Forms.CheckBox();
            this.cbthemphim3d = new System.Windows.Forms.CheckBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.nudthoiluongthem = new System.Windows.Forms.NumericUpDown();
            this.lbthoiluong = new System.Windows.Forms.Label();
            this.btxnthemphim = new System.Windows.Forms.Button();
            this.bthuythemphim = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.cbthemtlc = new System.Windows.Forms.ComboBox();
            this.lbtlchinh = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tbtenphimthem = new System.Windows.Forms.TextBox();
            this.lbTenphim = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbmaphimthem = new System.Windows.Forms.TextBox();
            this.lbmaphim = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudthoiluongthem)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.cbthemphimlongtieng);
            this.panel1.Controls.Add(this.cbthemphim3d);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.btxnthemphim);
            this.panel1.Controls.Add(this.bthuythemphim);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(532, 589);
            this.panel1.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.cbthemtlp);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(22, 231);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(478, 60);
            this.panel4.TabIndex = 8;
            // 
            // cbthemtlp
            // 
            this.cbthemtlp.FormattingEnabled = true;
            this.cbthemtlp.Location = new System.Drawing.Point(180, 14);
            this.cbthemtlp.Name = "cbthemtlp";
            this.cbthemtlp.Size = new System.Drawing.Size(277, 37);
            this.cbthemtlp.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Thể loại phụ";
            // 
            // cbthemphimlongtieng
            // 
            this.cbthemphimlongtieng.AutoSize = true;
            this.cbthemphimlongtieng.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbthemphimlongtieng.Location = new System.Drawing.Point(289, 419);
            this.cbthemphimlongtieng.Name = "cbthemphimlongtieng";
            this.cbthemphimlongtieng.Size = new System.Drawing.Size(152, 33);
            this.cbthemphimlongtieng.TabIndex = 7;
            this.cbthemphimlongtieng.Text = "Lồng tiếng";
            this.cbthemphimlongtieng.UseVisualStyleBackColor = true;
            // 
            // cbthemphim3d
            // 
            this.cbthemphim3d.AutoSize = true;
            this.cbthemphim3d.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbthemphim3d.Location = new System.Drawing.Point(108, 419);
            this.cbthemphim3d.Name = "cbthemphim3d";
            this.cbthemphim3d.Size = new System.Drawing.Size(69, 33);
            this.cbthemphim3d.TabIndex = 6;
            this.cbthemphim3d.Text = "3D";
            this.cbthemphim3d.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.nudthoiluongthem);
            this.panel6.Controls.Add(this.lbthoiluong);
            this.panel6.Location = new System.Drawing.Point(22, 297);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(478, 60);
            this.panel6.TabIndex = 4;
            // 
            // nudthoiluongthem
            // 
            this.nudthoiluongthem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.nudthoiluongthem.Location = new System.Drawing.Point(224, 16);
            this.nudthoiluongthem.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nudthoiluongthem.Name = "nudthoiluongthem";
            this.nudthoiluongthem.Size = new System.Drawing.Size(122, 35);
            this.nudthoiluongthem.TabIndex = 1;
            // 
            // lbthoiluong
            // 
            this.lbthoiluong.AutoSize = true;
            this.lbthoiluong.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbthoiluong.Location = new System.Drawing.Point(3, 22);
            this.lbthoiluong.Name = "lbthoiluong";
            this.lbthoiluong.Size = new System.Drawing.Size(196, 29);
            this.lbthoiluong.TabIndex = 0;
            this.lbthoiluong.Text = "Thời lượng (phút)";
            // 
            // btxnthemphim
            // 
            this.btxnthemphim.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btxnthemphim.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btxnthemphim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btxnthemphim.Location = new System.Drawing.Point(363, 496);
            this.btxnthemphim.Name = "btxnthemphim";
            this.btxnthemphim.Size = new System.Drawing.Size(137, 40);
            this.btxnthemphim.TabIndex = 5;
            this.btxnthemphim.Text = "Xác nhận";
            this.btxnthemphim.UseVisualStyleBackColor = false;
            this.btxnthemphim.Click += new System.EventHandler(this.btxnthemphim_Click);
            // 
            // bthuythemphim
            // 
            this.bthuythemphim.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bthuythemphim.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bthuythemphim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bthuythemphim.Location = new System.Drawing.Point(240, 496);
            this.bthuythemphim.Name = "bthuythemphim";
            this.bthuythemphim.Size = new System.Drawing.Size(81, 41);
            this.bthuythemphim.TabIndex = 4;
            this.bthuythemphim.Text = "Hủy";
            this.bthuythemphim.UseVisualStyleBackColor = false;
            this.bthuythemphim.Click += new System.EventHandler(this.bthuythemphim_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.cbthemtlc);
            this.panel5.Controls.Add(this.lbtlchinh);
            this.panel5.Location = new System.Drawing.Point(22, 165);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(478, 60);
            this.panel5.TabIndex = 3;
            // 
            // cbthemtlc
            // 
            this.cbthemtlc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbthemtlc.FormattingEnabled = true;
            this.cbthemtlc.Location = new System.Drawing.Point(180, 14);
            this.cbthemtlc.Name = "cbthemtlc";
            this.cbthemtlc.Size = new System.Drawing.Size(277, 37);
            this.cbthemtlc.TabIndex = 1;
            this.cbthemtlc.SelectedIndexChanged += new System.EventHandler(this.cbthemtlc_SelectedIndexChanged);
            // 
            // lbtlchinh
            // 
            this.lbtlchinh.AutoSize = true;
            this.lbtlchinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtlchinh.Location = new System.Drawing.Point(3, 22);
            this.lbtlchinh.Name = "lbtlchinh";
            this.lbtlchinh.Size = new System.Drawing.Size(164, 29);
            this.lbtlchinh.TabIndex = 0;
            this.lbtlchinh.Text = "Thể loại chính";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tbtenphimthem);
            this.panel3.Controls.Add(this.lbTenphim);
            this.panel3.Location = new System.Drawing.Point(22, 99);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(478, 60);
            this.panel3.TabIndex = 2;
            // 
            // tbtenphimthem
            // 
            this.tbtenphimthem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbtenphimthem.Location = new System.Drawing.Point(180, 16);
            this.tbtenphimthem.Name = "tbtenphimthem";
            this.tbtenphimthem.Size = new System.Drawing.Size(277, 35);
            this.tbtenphimthem.TabIndex = 1;
            // 
            // lbTenphim
            // 
            this.lbTenphim.AutoSize = true;
            this.lbTenphim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenphim.Location = new System.Drawing.Point(3, 19);
            this.lbTenphim.Name = "lbTenphim";
            this.lbTenphim.Size = new System.Drawing.Size(115, 29);
            this.lbTenphim.TabIndex = 0;
            this.lbTenphim.Text = "Tên phim";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tbmaphimthem);
            this.panel2.Controls.Add(this.lbmaphim);
            this.panel2.Location = new System.Drawing.Point(22, 33);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(478, 60);
            this.panel2.TabIndex = 1;
            // 
            // tbmaphimthem
            // 
            this.tbmaphimthem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbmaphimthem.Location = new System.Drawing.Point(180, 13);
            this.tbmaphimthem.Name = "tbmaphimthem";
            this.tbmaphimthem.Size = new System.Drawing.Size(277, 35);
            this.tbmaphimthem.TabIndex = 1;
            // 
            // lbmaphim
            // 
            this.lbmaphim.AutoSize = true;
            this.lbmaphim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmaphim.Location = new System.Drawing.Point(3, 19);
            this.lbmaphim.Name = "lbmaphim";
            this.lbmaphim.Size = new System.Drawing.Size(105, 29);
            this.lbmaphim.TabIndex = 0;
            this.lbmaphim.Text = "Mã phim";
            // 
            // Thêm_phim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(532, 589);
            this.Controls.Add(this.panel1);
            this.Name = "Thêm_phim";
            this.Text = "CGV - Thêm phim";
            this.Load += new System.EventHandler(this.Thêm_phim_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudthoiluongthem)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btxnthemphim;
        private System.Windows.Forms.Button bthuythemphim;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbtlchinh;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tbtenphimthem;
        private System.Windows.Forms.Label lbTenphim;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tbmaphimthem;
        private System.Windows.Forms.Label lbmaphim;
        private System.Windows.Forms.CheckBox cbthemphimlongtieng;
        private System.Windows.Forms.CheckBox cbthemphim3d;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.NumericUpDown nudthoiluongthem;
        private System.Windows.Forms.Label lbthoiluong;
        private System.Windows.Forms.ComboBox cbthemtlc;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox cbthemtlp;
        private System.Windows.Forms.Label label1;
    }
}