﻿namespace MyCGV
{
    partial class FormThêm_rạp_Q1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormThêm_rạp_Q1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbmacum = new System.Windows.Forms.Label();
            this.tbmacumq1 = new System.Windows.Forms.TextBox();
            this.btxacnhantrq1 = new System.Windows.Forms.Button();
            this.bthuysrq1 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.nudtonggherq1 = new System.Windows.Forms.NumericUpDown();
            this.lbsogheq1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbmarapq1 = new System.Windows.Forms.Label();
            this.tbmarapq1 = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudtonggherq1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.btxacnhantrq1);
            this.panel1.Controls.Add(this.bthuysrq1);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(508, 390);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lbmacum);
            this.panel4.Controls.Add(this.tbmacumq1);
            this.panel4.Location = new System.Drawing.Point(22, 175);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(464, 64);
            this.panel4.TabIndex = 2;
            // 
            // lbmacum
            // 
            this.lbmacum.AutoSize = true;
            this.lbmacum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbmacum.Location = new System.Drawing.Point(22, 20);
            this.lbmacum.Name = "lbmacum";
            this.lbmacum.Size = new System.Drawing.Size(97, 29);
            this.lbmacum.TabIndex = 0;
            this.lbmacum.Text = "Mã cụm";
            // 
            // tbmacumq1
            // 
            this.tbmacumq1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbmacumq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbmacumq1.Location = new System.Drawing.Point(184, 14);
            this.tbmacumq1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbmacumq1.Name = "tbmacumq1";
            this.tbmacumq1.ReadOnly = true;
            this.tbmacumq1.Size = new System.Drawing.Size(268, 35);
            this.tbmacumq1.TabIndex = 0;
            // 
            // btxacnhantrq1
            // 
            this.btxacnhantrq1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btxacnhantrq1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btxacnhantrq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btxacnhantrq1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btxacnhantrq1.Location = new System.Drawing.Point(318, 274);
            this.btxacnhantrq1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btxacnhantrq1.Name = "btxacnhantrq1";
            this.btxacnhantrq1.Size = new System.Drawing.Size(158, 40);
            this.btxacnhantrq1.TabIndex = 3;
            this.btxacnhantrq1.Text = "Xác nhận";
            this.btxacnhantrq1.UseVisualStyleBackColor = false;
            this.btxacnhantrq1.Click += new System.EventHandler(this.btxacnhantrq1_Click);
            // 
            // bthuysrq1
            // 
            this.bthuysrq1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bthuysrq1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bthuysrq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bthuysrq1.Location = new System.Drawing.Point(196, 272);
            this.bthuysrq1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bthuysrq1.Name = "bthuysrq1";
            this.bthuysrq1.Size = new System.Drawing.Size(97, 42);
            this.bthuysrq1.TabIndex = 4;
            this.bthuysrq1.Text = "Hủy";
            this.bthuysrq1.UseVisualStyleBackColor = false;
            this.bthuysrq1.Click += new System.EventHandler(this.bthuysrq1_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.nudtonggherq1);
            this.panel3.Controls.Add(this.lbsogheq1);
            this.panel3.Location = new System.Drawing.Point(22, 96);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(464, 64);
            this.panel3.TabIndex = 1;
            // 
            // nudtonggherq1
            // 
            this.nudtonggherq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.nudtonggherq1.Location = new System.Drawing.Point(184, 14);
            this.nudtonggherq1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nudtonggherq1.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nudtonggherq1.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nudtonggherq1.Name = "nudtonggherq1";
            this.nudtonggherq1.Size = new System.Drawing.Size(120, 35);
            this.nudtonggherq1.TabIndex = 0;
            this.nudtonggherq1.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // lbsogheq1
            // 
            this.lbsogheq1.AutoSize = true;
            this.lbsogheq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbsogheq1.Location = new System.Drawing.Point(22, 20);
            this.lbsogheq1.Name = "lbsogheq1";
            this.lbsogheq1.Size = new System.Drawing.Size(90, 29);
            this.lbsogheq1.TabIndex = 0;
            this.lbsogheq1.Text = "Số ghế";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbmarapq1);
            this.panel2.Controls.Add(this.tbmarapq1);
            this.panel2.Location = new System.Drawing.Point(22, 26);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(464, 64);
            this.panel2.TabIndex = 0;
            // 
            // lbmarapq1
            // 
            this.lbmarapq1.AutoSize = true;
            this.lbmarapq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbmarapq1.Location = new System.Drawing.Point(22, 20);
            this.lbmarapq1.Name = "lbmarapq1";
            this.lbmarapq1.Size = new System.Drawing.Size(87, 29);
            this.lbmarapq1.TabIndex = 0;
            this.lbmarapq1.Text = "Mã rạp";
            // 
            // tbmarapq1
            // 
            this.tbmarapq1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbmarapq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbmarapq1.Location = new System.Drawing.Point(184, 14);
            this.tbmarapq1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbmarapq1.Name = "tbmarapq1";
            this.tbmarapq1.Size = new System.Drawing.Size(268, 35);
            this.tbmarapq1.TabIndex = 0;
            // 
            // FormThêm_rạp_Q1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 390);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormThêm_rạp_Q1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CGV - Thêm rạp";
            this.Load += new System.EventHandler(this.FormThêm_rạp_Q1_Load);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudtonggherq1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbmarapq1;
        private System.Windows.Forms.TextBox tbmarapq1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbsogheq1;
        private System.Windows.Forms.Button btxacnhantrq1;
        private System.Windows.Forms.Button bthuysrq1;
        private System.Windows.Forms.NumericUpDown nudtonggherq1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbmacum;
        private System.Windows.Forms.TextBox tbmacumq1;
    }
}