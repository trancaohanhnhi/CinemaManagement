﻿namespace MyCGV
{
    partial class FormXoaQLLC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btxnx = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tbsuatchieux = new System.Windows.Forms.TextBox();
            this.sclcx = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tbngaychieulcx = new System.Windows.Forms.TextBox();
            this.nclcx = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tbmaraplcx = new System.Windows.Forms.TextBox();
            this.tenphimlcx = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbmaphimllcx = new System.Windows.Forms.TextBox();
            this.maphimlcx = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(496, 335);
            this.panel1.TabIndex = 2;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btxnx);
            this.panel6.Location = new System.Drawing.Point(3, 267);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(488, 64);
            this.panel6.TabIndex = 3;
            // 
            // btxnx
            // 
            this.btxnx.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btxnx.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btxnx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btxnx.Location = new System.Drawing.Point(307, 20);
            this.btxnx.Name = "btxnx";
            this.btxnx.Size = new System.Drawing.Size(155, 33);
            this.btxnx.TabIndex = 3;
            this.btxnx.Text = "Xác nhận xóa";
            this.btxnx.UseVisualStyleBackColor = false;
            this.btxnx.Click += new System.EventHandler(this.btxnx_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.tbsuatchieux);
            this.panel5.Controls.Add(this.sclcx);
            this.panel5.Location = new System.Drawing.Point(3, 201);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(488, 64);
            this.panel5.TabIndex = 2;
            // 
            // tbsuatchieux
            // 
            this.tbsuatchieux.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbsuatchieux.Location = new System.Drawing.Point(164, 17);
            this.tbsuatchieux.Name = "tbsuatchieux";
            this.tbsuatchieux.Size = new System.Drawing.Size(298, 30);
            this.tbsuatchieux.TabIndex = 3;
            // 
            // sclcx
            // 
            this.sclcx.AutoSize = true;
            this.sclcx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.sclcx.Location = new System.Drawing.Point(3, 22);
            this.sclcx.Name = "sclcx";
            this.sclcx.Size = new System.Drawing.Size(105, 25);
            this.sclcx.TabIndex = 0;
            this.sclcx.Text = "Suất chiếu";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.tbngaychieulcx);
            this.panel4.Controls.Add(this.nclcx);
            this.panel4.Location = new System.Drawing.Point(3, 135);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(488, 64);
            this.panel4.TabIndex = 2;
            // 
            // tbngaychieulcx
            // 
            this.tbngaychieulcx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbngaychieulcx.Location = new System.Drawing.Point(164, 17);
            this.tbngaychieulcx.Name = "tbngaychieulcx";
            this.tbngaychieulcx.ReadOnly = true;
            this.tbngaychieulcx.ShortcutsEnabled = false;
            this.tbngaychieulcx.Size = new System.Drawing.Size(298, 30);
            this.tbngaychieulcx.TabIndex = 2;
            // 
            // nclcx
            // 
            this.nclcx.AutoSize = true;
            this.nclcx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.nclcx.Location = new System.Drawing.Point(3, 22);
            this.nclcx.Name = "nclcx";
            this.nclcx.Size = new System.Drawing.Size(110, 25);
            this.nclcx.TabIndex = 0;
            this.nclcx.Text = "Ngày chiếu";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tbmaraplcx);
            this.panel3.Controls.Add(this.tenphimlcx);
            this.panel3.Location = new System.Drawing.Point(3, 69);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(488, 64);
            this.panel3.TabIndex = 2;
            // 
            // tbmaraplcx
            // 
            this.tbmaraplcx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbmaraplcx.Location = new System.Drawing.Point(164, 17);
            this.tbmaraplcx.Name = "tbmaraplcx";
            this.tbmaraplcx.ReadOnly = true;
            this.tbmaraplcx.Size = new System.Drawing.Size(298, 30);
            this.tbmaraplcx.TabIndex = 1;
            this.tbmaraplcx.TabStop = false;
            // 
            // tenphimlcx
            // 
            this.tenphimlcx.AutoSize = true;
            this.tenphimlcx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tenphimlcx.Location = new System.Drawing.Point(3, 22);
            this.tenphimlcx.Name = "tenphimlcx";
            this.tenphimlcx.Size = new System.Drawing.Size(47, 25);
            this.tenphimlcx.TabIndex = 0;
            this.tenphimlcx.Text = "Rạp";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tbmaphimllcx);
            this.panel2.Controls.Add(this.maphimlcx);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(488, 64);
            this.panel2.TabIndex = 0;
            // 
            // tbmaphimllcx
            // 
            this.tbmaphimllcx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.tbmaphimllcx.Location = new System.Drawing.Point(164, 17);
            this.tbmaphimllcx.Name = "tbmaphimllcx";
            this.tbmaphimllcx.ReadOnly = true;
            this.tbmaphimllcx.Size = new System.Drawing.Size(298, 30);
            this.tbmaphimllcx.TabIndex = 1;
            // 
            // maphimlcx
            // 
            this.maphimlcx.AutoSize = true;
            this.maphimlcx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.maphimlcx.Location = new System.Drawing.Point(3, 22);
            this.maphimlcx.Name = "maphimlcx";
            this.maphimlcx.Size = new System.Drawing.Size(87, 25);
            this.maphimlcx.TabIndex = 0;
            this.maphimlcx.Text = "Mã phim";
            // 
            // FormXoaQLLC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(496, 335);
            this.Controls.Add(this.panel1);
            this.Name = "FormXoaQLLC";
            this.Text = "CGV - Xóa lịch chiếu";
            this.Load += new System.EventHandler(this.FormXoaQLLC_Load);
            this.panel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btxnx;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox tbsuatchieux;
        private System.Windows.Forms.Label sclcx;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox tbngaychieulcx;
        private System.Windows.Forms.Label nclcx;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tbmaraplcx;
        private System.Windows.Forms.Label tenphimlcx;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tbmaphimllcx;
        private System.Windows.Forms.Label maphimlcx;
    }
}