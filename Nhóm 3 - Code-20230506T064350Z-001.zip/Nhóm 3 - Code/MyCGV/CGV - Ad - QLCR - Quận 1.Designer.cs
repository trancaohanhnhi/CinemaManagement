﻿namespace MyCGV
{
    partial class FormCGV_Quận_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCGV_Quận_1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btthemrapcgvq1 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btsuacgvq1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgvcgvq1 = new System.Windows.Forms.DataGridView();
            this.MaRap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongGhe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaCum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbcgvq1 = new System.Windows.Forms.Label();
            this.tbSearch = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvcgvq1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.lbcgvq1);
            this.panel1.Controls.Add(this.tbSearch);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(837, 539);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.btthemrapcgvq1);
            this.panel4.Location = new System.Drawing.Point(685, 62);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(124, 46);
            this.panel4.TabIndex = 2;
            // 
            // btthemrapcgvq1
            // 
            this.btthemrapcgvq1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btthemrapcgvq1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btthemrapcgvq1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btthemrapcgvq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btthemrapcgvq1.Location = new System.Drawing.Point(10, 3);
            this.btthemrapcgvq1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btthemrapcgvq1.Name = "btthemrapcgvq1";
            this.btthemrapcgvq1.Size = new System.Drawing.Size(111, 38);
            this.btthemrapcgvq1.TabIndex = 0;
            this.btthemrapcgvq1.Text = "Thêm";
            this.btthemrapcgvq1.UseVisualStyleBackColor = false;
            this.btthemrapcgvq1.Click += new System.EventHandler(this.btthemrapcgvq1_Click);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.btsuacgvq1);
            this.panel3.Location = new System.Drawing.Point(567, 62);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(102, 46);
            this.panel3.TabIndex = 3;
            // 
            // btsuacgvq1
            // 
            this.btsuacgvq1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btsuacgvq1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btsuacgvq1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btsuacgvq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btsuacgvq1.Location = new System.Drawing.Point(4, 3);
            this.btsuacgvq1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btsuacgvq1.Name = "btsuacgvq1";
            this.btsuacgvq1.Size = new System.Drawing.Size(96, 38);
            this.btsuacgvq1.TabIndex = 0;
            this.btsuacgvq1.Text = "Sửa";
            this.btsuacgvq1.UseVisualStyleBackColor = false;
            this.btsuacgvq1.Click += new System.EventHandler(this.btsuacgvq1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(779, 26);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(28, 25);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.dgvcgvq1);
            this.panel2.Location = new System.Drawing.Point(11, 122);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(812, 400);
            this.panel2.TabIndex = 4;
            // 
            // dgvcgvq1
            // 
            this.dgvcgvq1.AllowUserToAddRows = false;
            this.dgvcgvq1.AllowUserToDeleteRows = false;
            this.dgvcgvq1.AllowUserToOrderColumns = true;
            this.dgvcgvq1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvcgvq1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvcgvq1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvcgvq1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvcgvq1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaRap,
            this.TongGhe,
            this.MaCum});
            this.dgvcgvq1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvcgvq1.GridColor = System.Drawing.SystemColors.ActiveBorder;
            this.dgvcgvq1.Location = new System.Drawing.Point(0, 0);
            this.dgvcgvq1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvcgvq1.Name = "dgvcgvq1";
            this.dgvcgvq1.ReadOnly = true;
            this.dgvcgvq1.RowHeadersWidth = 62;
            this.dgvcgvq1.RowTemplate.Height = 28;
            this.dgvcgvq1.Size = new System.Drawing.Size(812, 400);
            this.dgvcgvq1.TabIndex = 0;
            this.dgvcgvq1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvcgvq1_CellClick);
            // 
            // MaRap
            // 
            this.MaRap.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.MaRap.DataPropertyName = "MaRap";
            this.MaRap.FillWeight = 10F;
            this.MaRap.HeaderText = "Mã rạp";
            this.MaRap.MinimumWidth = 8;
            this.MaRap.Name = "MaRap";
            this.MaRap.ReadOnly = true;
            // 
            // TongGhe
            // 
            this.TongGhe.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.TongGhe.DataPropertyName = "TongGhe";
            this.TongGhe.FillWeight = 10F;
            this.TongGhe.HeaderText = "Tổng ghế";
            this.TongGhe.MinimumWidth = 8;
            this.TongGhe.Name = "TongGhe";
            this.TongGhe.ReadOnly = true;
            // 
            // MaCum
            // 
            this.MaCum.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.MaCum.DataPropertyName = "MaCum";
            this.MaCum.FillWeight = 10F;
            this.MaCum.HeaderText = "Mã cụm";
            this.MaCum.MinimumWidth = 8;
            this.MaCum.Name = "MaCum";
            this.MaCum.ReadOnly = true;
            // 
            // lbcgvq1
            // 
            this.lbcgvq1.AutoSize = true;
            this.lbcgvq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbcgvq1.Location = new System.Drawing.Point(11, 29);
            this.lbcgvq1.Name = "lbcgvq1";
            this.lbcgvq1.Size = new System.Drawing.Size(191, 31);
            this.lbcgvq1.TabIndex = 1;
            this.lbcgvq1.Text = "CGV QUẬN 1";
            // 
            // tbSearch
            // 
            this.tbSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSearch.Location = new System.Drawing.Point(565, 25);
            this.tbSearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbSearch.Name = "tbSearch";
            this.tbSearch.Size = new System.Drawing.Size(244, 30);
            this.tbSearch.TabIndex = 0;
            this.tbSearch.TextChanged += new System.EventHandler(this.tbSearch_TextChanged);
            // 
            // FormCGV_Quận_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 539);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormCGV_Quận_1";
            this.Text = "CGV_Quận_1";
            this.Load += new System.EventHandler(this.FormCGV_Quận_1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvcgvq1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbcgvq1;
        private System.Windows.Forms.Button btthemrapcgvq1;
        private System.Windows.Forms.Button btsuacgvq1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tbSearch;
        private System.Windows.Forms.DataGridView dgvcgvq1;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaRap;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongGhe;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaCum;
    }
}